package ua.nure.sheryuliy.practice1;

public class Task1 {
	public void hello() {
		System.out.println("Hello, world!");
	}
}
