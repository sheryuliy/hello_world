package ua.nure.sheryuliy.practice1;

public class Task2 {
	int sum;
	public int summa(int a, int b) {
		sum = a + b;
		return sum;
	}
}
